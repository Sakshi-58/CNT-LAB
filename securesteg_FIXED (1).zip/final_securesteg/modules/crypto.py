"""
crypto.py — AES-256 CBC + RSA-2048 implementation
Uses PyCryptodome
"""
import os
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes


# ── AES-256 CBC ───────────────────────────────────────────────────────────────

class AESCipher:
    """AES-256 in CBC mode with random IV prepended to ciphertext."""

    KEY_SIZE = 32   # 256 bits
    BLOCK    = 16

    def __init__(self, key: bytes):
        if len(key) != self.KEY_SIZE:
            raise ValueError(f"Key must be {self.KEY_SIZE} bytes, got {len(key)}")
        self.key = key

    @staticmethod
    def generate_key() -> bytes:
        """Generate a random 256-bit AES key."""
        return get_random_bytes(AESCipher.KEY_SIZE)

    def encrypt(self, plaintext: bytes) -> bytes:
        """Encrypt plaintext → IV || ciphertext (both binary)."""
        iv     = get_random_bytes(self.BLOCK)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        ct     = cipher.encrypt(pad(plaintext, self.BLOCK))
        return iv + ct

    def decrypt(self, data: bytes) -> bytes:
        """Decrypt IV || ciphertext back to plaintext."""
        iv, ct = data[:self.BLOCK], data[self.BLOCK:]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return unpad(cipher.decrypt(ct), self.BLOCK)


# ── RSA-2048 ──────────────────────────────────────────────────────────────────

class RSAKeyPair:
    """RSA-2048 key pair — generate, import/export, encrypt/decrypt."""

    KEY_BITS = 2048

    def __init__(self, *, public_key_pem: str = None, private_key_pem: str = None):
        if private_key_pem:
            self._key = RSA.import_key(private_key_pem)
        elif public_key_pem:
            self._key = RSA.import_key(public_key_pem)
        else:
            self._key = RSA.generate(self.KEY_BITS)

    # ── Export ─────────────────────────────────────────────────────────────

    def export_public_key(self) -> str:
        return self._key.publickey().export_key().decode()

    def export_private_key(self) -> str:
        if not self._key.has_private():
            raise ValueError("No private key available")
        return self._key.export_key().decode()

    # ── Encrypt / Decrypt ──────────────────────────────────────────────────

    def encrypt(self, plaintext: bytes) -> bytes:
        cipher = PKCS1_OAEP.new(self._key.publickey() if self._key.has_private() else self._key)
        return cipher.encrypt(plaintext)

    def decrypt(self, ciphertext: bytes) -> bytes:
        if not self._key.has_private():
            raise ValueError("Private key required for decryption")
        cipher = PKCS1_OAEP.new(self._key)
        return cipher.decrypt(ciphertext)

    # ── Hybrid: RSA-wrapped AES key ────────────────────────────────────────

    def wrap_aes_key(self, aes_key: bytes) -> bytes:
        """Encrypt an AES key with RSA public key (key wrapping)."""
        return self.encrypt(aes_key)

    def unwrap_aes_key(self, wrapped_key: bytes) -> bytes:
        """Decrypt a wrapped AES key with RSA private key."""
        return self.decrypt(wrapped_key)
