"""
steganalysis.py — Statistical steganalysis using Chi-square attack on LSB plane.
A high chi-square score → strong suspicion of LSB steganography.
"""
import io
import math
from PIL import Image


class StegAnalyzer:
    """Detect LSB steganography in images via Chi-square and RS analysis."""

    CHI_THRESHOLD    = 0.05   # p-value below this → suspicious
    SAMPLE_BLOCKS    = 8      # number of blocks to sample across image

    def analyze(self, image_bytes: bytes) -> dict:
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        chi_result  = self._chi_square_attack(img)
        rs_result   = self._rs_analysis(img)
        lsb_visual  = self._lsb_plane_stats(img)
        suspicious  = chi_result['suspicious'] or rs_result['suspicious']
        return {
            'suspicious': suspicious,
            'verdict': 'LIKELY CONTAINS HIDDEN DATA' if suspicious else 'APPEARS CLEAN',
            'chi_square': chi_result,
            'rs_analysis': rs_result,
            'lsb_stats': lsb_visual,
            'image_size': {'width': img.width, 'height': img.height},
            'max_hidden_bytes': (img.width * img.height * 3) // 8,
        }

    # ── Chi-Square Attack ──────────────────────────────────────────────────

    def _chi_square_attack(self, img: Image.Image) -> dict:
        """
        Chi-square test on pairs of pixel values (2k, 2k+1).
        If LSB is random (steganography), these pairs should be equally frequent.
        """
        pixels = list(img.getdata())
        # Collect red channel values
        red_vals = [p[0] for p in pixels]
        # Count frequency of each value 0–255
        freq = [0] * 256
        for v in red_vals:
            freq[v] += 1
        # For each pair (2k, 2k+1), expected = (obs_2k + obs_2k+1) / 2
        chi2    = 0.0
        pairs   = 0
        for k in range(128):
            obs_even = freq[2 * k]
            obs_odd  = freq[2 * k + 1]
            expected = (obs_even + obs_odd) / 2.0
            if expected > 0:
                chi2  += ((obs_even - expected) ** 2) / expected
                chi2  += ((obs_odd  - expected) ** 2) / expected
                pairs += 1
        # Approximate p-value (chi2 with pairs degrees of freedom)
        p_value = self._chi2_p_value(chi2, pairs)
        return {
            'chi2_statistic': round(chi2, 4),
            'p_value':        round(p_value, 6),
            'degrees_of_freedom': pairs,
            'suspicious':     p_value < self.CHI_THRESHOLD,
            'interpretation': (
                f"p={p_value:.4f} — {'suspicious (LSB manipulation detected)' if p_value < self.CHI_THRESHOLD else 'normal distribution'}"
            ),
        }

    # ── RS Analysis ───────────────────────────────────────────────────────

    def _rs_analysis(self, img: Image.Image) -> dict:
        """
        Simplified RS analysis: compare smoothness of original vs. flipped LSB image.
        Large |Rm - Sm| suggests hidden data.
        """
        pixels    = [p[0] for p in img.getdata()]
        width     = img.width
        block_size = 4
        r_count = s_count = m_count = 0
        total_blocks = 0
        for start in range(0, len(pixels) - block_size, block_size):
            block    = pixels[start:start + block_size]
            f_orig   = self._smoothness(block)
            flipped  = [(v ^ 1) for v in block]
            f_flip   = self._smoothness(flipped)
            if f_orig > f_flip:
                r_count += 1
            elif f_orig < f_flip:
                s_count += 1
            else:
                m_count += 1
            total_blocks += 1
        if total_blocks == 0:
            return {'suspicious': False, 'error': 'Image too small'}
        rm = r_count / total_blocks
        sm = s_count / total_blocks
        diff = abs(rm - sm)
        return {
            'R':          round(rm, 4),
            'S':          round(sm, 4),
            'difference': round(diff, 4),
            'suspicious': diff > 0.05,
            'interpretation': (
                f"R={rm:.3f}, S={sm:.3f} — {'asymmetric (hidden data suspected)' if diff > 0.05 else 'symmetric (likely clean)'}"
            ),
        }

    # ── LSB Plane Statistics ──────────────────────────────────────────────

    def _lsb_plane_stats(self, img: Image.Image) -> dict:
        pixels   = list(img.getdata())
        r_lsb    = [p[0] & 1 for p in pixels]
        ones     = sum(r_lsb)
        total    = len(r_lsb)
        ratio    = ones / total if total else 0
        # Perfectly random LSB (steganography) → ratio ≈ 0.5
        deviation = abs(ratio - 0.5)
        return {
            'lsb_ones_ratio': round(ratio, 4),
            'deviation_from_random': round(deviation, 4),
            'interpretation': (
                f"LSB ratio={ratio:.3f} — {'near-random (suspicious)' if deviation < 0.02 else 'natural distribution'}"
            ),
        }

    # ── Math Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _smoothness(block: list) -> float:
        return sum(abs(block[i] - block[i-1]) for i in range(1, len(block)))

    @staticmethod
    def _chi2_p_value(chi2: float, df: int) -> float:
        """Approximate p-value using regularized incomplete gamma function."""
        if df <= 0 or chi2 < 0:
            return 1.0
        try:
            return StegAnalyzer._regularized_upper_gamma(df / 2, chi2 / 2)
        except Exception:
            return 1.0

    @staticmethod
    def _regularized_upper_gamma(a: float, x: float) -> float:
        """Approximate upper regularized incomplete gamma Q(a, x) via series."""
        if x < 0:
            return 1.0
        if x == 0:
            return 1.0
        # Use continued fraction for large x, series for small x
        MAX_ITER = 200
        EPS      = 1e-8
        if x < a + 1:
            # Series expansion for lower gamma, then Q = 1 - P
            ap  = a
            s   = 1.0 / a
            delta = s
            for _ in range(MAX_ITER):
                ap    += 1
                delta *= x / ap
                s     += delta
                if abs(delta) < abs(s) * EPS:
                    break
            lower = s * math.exp(-x + a * math.log(x) - math.lgamma(a))
            return max(0.0, 1.0 - lower)
        else:
            # Lentz continued fraction
            b   = x + 1.0 - a
            c   = 1.0 / 1e-30
            d   = 1.0 / b
            h   = d
            for i in range(1, MAX_ITER + 1):
                an  = -i * (i - a)
                b  += 2.0
                d   = an * d + b
                if abs(d) < 1e-30:
                    d = 1e-30
                c   = b + an / c
                if abs(c) < 1e-30:
                    c = 1e-30
                d   = 1.0 / d
                delta = d * c
                h    *= delta
                if abs(delta - 1.0) < EPS:
                    break
            return math.exp(-x + a * math.log(x) - math.lgamma(a)) * h
