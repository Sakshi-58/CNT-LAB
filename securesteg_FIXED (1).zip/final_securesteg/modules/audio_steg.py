"""
audio_steg.py — LSB Audio Steganography for WAV files.
Uses Python's built-in `wave` module + struct.
"""
import io
import wave
import struct

DELIMITER = "<<END>>"


class AudioSteganography:
    """Hide / extract text messages in WAV audio using LSB on 16-bit samples."""

    def embed(self, audio_bytes: bytes, message: str) -> bytes:
        payload = message + DELIMITER
        bits    = self._to_bits(payload)
        buf_in  = io.BytesIO(audio_bytes)
        buf_out = io.BytesIO()
        with wave.open(buf_in, 'rb') as wav_in:
            params  = wav_in.getparams()
            n_frames = wav_in.getnframes()
            raw     = wav_in.readframes(n_frames)
        # Work with 16-bit PCM
        if params.sampwidth != 2:
            raise ValueError("Only 16-bit PCM WAV supported.")
        samples = list(struct.unpack(f'<{n_frames * params.nchannels}h', raw))
        if len(bits) > len(samples):
            raise ValueError(
                f"Message too large: needs {len(bits)} samples, audio has {len(samples)}."
            )
        for i, bit in enumerate(bits):
            samples[i] = (samples[i] & ~1) | bit
        new_raw = struct.pack(f'<{len(samples)}h', *samples)
        with wave.open(buf_out, 'wb') as wav_out:
            wav_out.setparams(params)
            wav_out.writeframes(new_raw)
        return buf_out.getvalue()

    def extract(self, audio_bytes: bytes) -> str:
        buf_in = io.BytesIO(audio_bytes)
        with wave.open(buf_in, 'rb') as wav_in:
            params   = wav_in.getparams()
            n_frames = wav_in.getnframes()
            raw      = wav_in.readframes(n_frames)
        if params.sampwidth != 2:
            raise ValueError("Only 16-bit PCM WAV supported.")
        samples = struct.unpack(f'<{n_frames * params.nchannels}h', raw)
        bits    = [s & 1 for s in samples]
        chars   = []
        for i in range(0, len(bits) - 7, 8):
            byte = 0
            for j in range(8):
                byte = (byte << 1) | bits[i + j]
            chars.append(chr(byte))
            if ''.join(chars[-len(DELIMITER):]) == DELIMITER:
                return ''.join(chars[:-len(DELIMITER)])
        raise ValueError("No hidden message found or audio not encoded with SecureSteg.")

    @staticmethod
    def _to_bits(text: str) -> list:
        bits = []
        for ch in text:
            b = format(ord(ch), '08b')
            bits.extend([int(x) for x in b])
        return bits
