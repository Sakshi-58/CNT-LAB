"""
image_steg.py — LSB (Least Significant Bit) Image Steganography
Supports PNG and BMP. Uses Pillow.
"""
import io
import struct
from PIL import Image

DELIMITER = "<<END>>"


class ImageSteganography:
    """Hide / extract text payloads in images using LSB encoding."""

    # ── Public API ─────────────────────────────────────────────────────────

    def embed(self, image_bytes: bytes, message: str) -> bytes:
        """Embed message into image bytes; returns modified image as PNG bytes."""
        img  = self._load(image_bytes)
        data = self._to_bits(message + DELIMITER)
        self._check_capacity(img, len(data))
        pixels = list(img.getdata())
        new_pixels = []
        bit_idx = 0
        for pixel in pixels:
            r, g, b = pixel[:3]
            a = pixel[3] if len(pixel) == 4 else None
            if bit_idx < len(data):
                r = (r & ~1) | int(data[bit_idx]);     bit_idx += 1
            if bit_idx < len(data):
                g = (g & ~1) | int(data[bit_idx]);     bit_idx += 1
            if bit_idx < len(data):
                b = (b & ~1) | int(data[bit_idx]);     bit_idx += 1
            new_pixels.append((r, g, b, a) if a is not None else (r, g, b))
        out = Image.new(img.mode, img.size)
        out.putdata(new_pixels)
        buf = io.BytesIO()
        out.save(buf, format='PNG')
        return buf.getvalue()

    def extract(self, image_bytes: bytes) -> str:
        """Extract hidden message from image bytes."""
        img    = self._load(image_bytes)
        pixels = list(img.getdata())
        bits   = []
        for pixel in pixels:
            r, g, b = pixel[:3]
            bits.extend([r & 1, g & 1, b & 1])
        chars = []
        for i in range(0, len(bits) - 7, 8):
            byte = 0
            for j in range(8):
                byte = (byte << 1) | bits[i + j]
            chars.append(chr(byte))
            if ''.join(chars[-len(DELIMITER):]) == DELIMITER:
                return ''.join(chars[:-len(DELIMITER)])
        raise ValueError("No hidden message found or image not encoded with SecureSteg.")

    def capacity(self, image_bytes: bytes) -> int:
        """Return maximum number of bits that can be hidden."""
        img = self._load(image_bytes)
        w, h = img.size
        return w * h * 3   # 3 bits per pixel (R, G, B LSB)

    # ── Helpers ────────────────────────────────────────────────────────────

    def _load(self, image_bytes: bytes) -> Image.Image:
        img = Image.open(io.BytesIO(image_bytes))
        if img.mode not in ('RGB', 'RGBA'):
            img = img.convert('RGB')
        return img

    @staticmethod
    def _to_bits(text: str) -> list:
        bits = []
        for char in text:
            b = format(ord(char), '08b')
            bits.extend([int(x) for x in b])
        return bits

    def _check_capacity(self, img: Image.Image, needed_bits: int):
        w, h = img.size
        available = w * h * 3
        if needed_bits > available:
            raise ValueError(
                f"Message too large: needs {needed_bits} bits, image holds {available} bits."
            )
