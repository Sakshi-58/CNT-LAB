# SecureSteg — Encrypted Steganography Suite

A full-stack Python + Flask project combining **AES-256 encryption**, **RSA-2048 key exchange**, **LSB image & audio steganography**, and **statistical steganalysis**.

---

## 🗂️ Project Structure

```
securesteg/
├── app.py                  # Flask web server + all API routes
├── requirements.txt
├── modules/
│   ├── crypto.py           # AES-256 CBC + RSA-2048 OAEP
│   ├── image_steg.py       # LSB image steganography (PNG/BMP)
│   ├── audio_steg.py       # LSB audio steganography (WAV 16-bit)
│   └── steganalysis.py     # Chi-square + RS statistical analysis
└── templates/
    └── index.html          # Full web UI dashboard
```

---

## ⚙️ Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the server
```bash
python app.py
```

### 3. Open browser
```
http://localhost:5000
```

---

## 🧩 Modules & Features

### 1. AES-256 Encryption (`modules/crypto.py`)
- AES-256 in **CBC mode** with random IV
- IV is prepended to ciphertext for transport
- One-click key generation (32 random bytes)

### 2. RSA-2048 (`modules/crypto.py`)
- 2048-bit RSA key pair generation
- OAEP padding (PKCS1_OAEP) for secure encryption
- Key wrapping: encrypt AES key with RSA public key

### 3. Image Steganography (`modules/image_steg.py`)
- **LSB (Least Significant Bit)** encoding in PNG/BMP
- Hides 3 bits per pixel (R, G, B channels)
- Capacity = width × height × 3 bits
- Delimiter-based message boundary detection
- Optional AES-256 encryption before embedding

### 4. Audio Steganography (`modules/audio_steg.py`)
- LSB encoding in 16-bit PCM WAV samples
- Hides 1 bit per audio sample
- Preserves WAV format and metadata

### 5. Steganalysis (`modules/steganalysis.py`)
- **Chi-square attack**: tests if LSB values are unnaturally random
- **RS Analysis**: measures smoothness of original vs. flipped LSB
- **LSB plane stats**: ones ratio deviation from 0.5
- Returns verdict: LIKELY CONTAINS HIDDEN DATA / APPEARS CLEAN

---

## 🎓 Syllabus Coverage

| Feature | Unit Covered |
|---|---|
| AES-256 CBC, Block cipher modes | Unit 2 — Cryptography |
| RSA-2048, key generation, OAEP | Unit 2 — Public Key Cryptography |
| LSB Steganography | Unit 2 & 3 |
| Statistical Steganalysis (Chi-square) | Unit 4 — Cyber Attacks |
| Secure application design | Unit 3 — Application Security |
| Flask API, input validation | Unit 3 — Secure Coding |

---

## 🔬 How the Pipeline Works

```
SECRET MESSAGE
     │
     ▼
[AES-256 CBC Encrypt] ◄── random 256-bit key
     │
     ▼
base64-encoded ciphertext
     │
     ▼
[LSB Embed] ─── into PNG/WAV carrier file
     │
     ▼
STEGO FILE (visually/audibly identical to original)

─── Receiver side ───

STEGO FILE
     │
     ▼
[LSB Extract]
     │
     ▼
base64 ciphertext
     │
     ▼
[AES-256 CBC Decrypt] ◄── shared key (via RSA key exchange)
     │
     ▼
SECRET MESSAGE ✓
```

---

## 🛠️ Tech Stack

| Library | Purpose |
|---|---|
| Flask | Web server & REST API |
| PyCryptodome | AES-256, RSA-2048 cryptography |
| Pillow | Image processing (PNG/BMP) |
| wave (stdlib) | WAV audio processing |
| struct (stdlib) | Binary audio sample manipulation |

---

## 📊 Steganalysis Theory

### Chi-Square Attack
For natural images, the frequency of pixel values 2k and 2k+1 follows a natural distribution. When LSB steganography is applied, these pairs become equally frequent (LSBs become pseudo-random). A chi-square test detects this uniformity — a **low p-value (< 0.05)** signals suspicious content.

### RS Analysis
Measures the "smoothness" of pixel blocks. Natural images have predictable smoothness; LSB-modified images show asymmetry between regular (R) and singular (S) groups. A high |R - S| difference indicates hidden data.

---

## 🚀 Future Enhancements (Semester Extension)
- Video steganography (frame-by-frame using OpenCV)
- DCT-domain steganography (JPEG, more robust)
- Email alerts when suspicious image detected
- Blockchain audit log for stego file provenance
- ML-based steganalysis (SRM features + SVM)
