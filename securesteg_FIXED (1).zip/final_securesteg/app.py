from flask import Flask, render_template, request, jsonify, send_file
import os, io, base64, json
from modules.crypto import AESCipher, RSAKeyPair
from modules.image_steg import ImageSteganography
from modules.audio_steg import AudioSteganography
from modules.steganalysis import StegAnalyzer

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

# ── AES Crypto ────────────────────────────────────────────────────────────────

@app.route('/api/aes/generate-key', methods=['POST'])
def aes_generate_key():
    key_b64 = base64.b64encode(AESCipher.generate_key()).decode()
    return jsonify({'key': key_b64})

@app.route('/api/aes/encrypt', methods=['POST'])
def aes_encrypt():
    data = request.get_json()
    plaintext = data.get('plaintext', '')
    key_b64   = data.get('key', '')
    try:
        key        = base64.b64decode(key_b64)
        cipher     = AESCipher(key)
        ciphertext = cipher.encrypt(plaintext.encode())
        return jsonify({'ciphertext': base64.b64encode(ciphertext).decode()})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/aes/decrypt', methods=['POST'])
def aes_decrypt():
    data = request.get_json()
    ciphertext_b64 = data.get('ciphertext', '')
    key_b64        = data.get('key', '')
    try:
        key       = base64.b64decode(key_b64)
        ciphertext = base64.b64decode(ciphertext_b64)
        cipher    = AESCipher(key)
        plaintext = cipher.decrypt(ciphertext)
        return jsonify({'plaintext': plaintext.decode()})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# ── RSA Crypto ────────────────────────────────────────────────────────────────

@app.route('/api/rsa/generate-keys', methods=['POST'])
def rsa_generate_keys():
    rsa = RSAKeyPair()
    return jsonify({
        'public_key':  rsa.export_public_key(),
        'private_key': rsa.export_private_key(),
    })

@app.route('/api/rsa/encrypt', methods=['POST'])
def rsa_encrypt():
    data = request.get_json()
    try:
        rsa = RSAKeyPair(public_key_pem=data['public_key'])
        ct  = rsa.encrypt(data['plaintext'].encode())
        return jsonify({'ciphertext': base64.b64encode(ct).decode()})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/rsa/decrypt', methods=['POST'])
def rsa_decrypt():
    data = request.get_json()
    try:
        rsa = RSAKeyPair(private_key_pem=data['private_key'])
        pt  = rsa.decrypt(base64.b64decode(data['ciphertext']))
        return jsonify({'plaintext': pt.decode()})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# ── Image Steganography ───────────────────────────────────────────────────────

@app.route('/api/image/embed', methods=['POST'])
def image_embed():
    image_file = request.files.get('image')
    message    = request.form.get('message', '')
    key_b64    = request.form.get('key', '')
    encrypt    = request.form.get('encrypt', 'false') == 'true'
    try:
        img_bytes = image_file.read()
        if encrypt and key_b64:
            key     = base64.b64decode(key_b64)
            cipher  = AESCipher(key)
            payload = base64.b64encode(cipher.encrypt(message.encode())).decode()
        else:
            payload = message
        steg       = ImageSteganography()
        out_bytes  = steg.embed(img_bytes, payload)
        capacity   = steg.capacity(img_bytes)
        b64_out    = base64.b64encode(out_bytes).decode()
        return jsonify({
            'image': b64_out,
            'bits_used': len(payload) * 8,
            'capacity_bits': capacity,
            'encrypted': encrypt,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/image/extract', methods=['POST'])
def image_extract():
    image_file = request.files.get('image')
    key_b64    = request.form.get('key', '')
    decrypt    = request.form.get('decrypt', 'false') == 'true'
    try:
        img_bytes = image_file.read()
        steg      = ImageSteganography()
        payload   = steg.extract(img_bytes)
        if decrypt and key_b64:
            key     = base64.b64decode(key_b64)
            cipher  = AESCipher(key)
            raw     = cipher.decrypt(base64.b64decode(payload))
            message = raw.decode()
        else:
            message = payload
        return jsonify({'message': message})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# ── Audio Steganography ───────────────────────────────────────────────────────

@app.route('/api/audio/embed', methods=['POST'])
def audio_embed():
    audio_file = request.files.get('audio')
    message    = request.form.get('message', '')
    key_b64    = request.form.get('key', '')
    encrypt    = request.form.get('encrypt', 'false') == 'true'
    try:
        audio_bytes = audio_file.read()
        if encrypt and key_b64:
            key     = base64.b64decode(key_b64)
            cipher  = AESCipher(key)
            payload = base64.b64encode(cipher.encrypt(message.encode())).decode()
        else:
            payload = message
        steg      = AudioSteganography()
        out_bytes = steg.embed(audio_bytes, payload)
        b64_out   = base64.b64encode(out_bytes).decode()
        return jsonify({'audio': b64_out, 'encrypted': encrypt})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/audio/extract', methods=['POST'])
def audio_extract():
    audio_file = request.files.get('audio')
    key_b64    = request.form.get('key', '')
    decrypt    = request.form.get('decrypt', 'false') == 'true'
    try:
        audio_bytes = audio_file.read()
        steg        = AudioSteganography()
        payload     = steg.extract(audio_bytes)
        if decrypt and key_b64:
            key     = base64.b64decode(key_b64)
            cipher  = AESCipher(key)
            raw     = cipher.decrypt(base64.b64decode(payload))
            message = raw.decode()
        else:
            message = payload
        return jsonify({'message': message})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# ── Steganalysis ──────────────────────────────────────────────────────────────

@app.route('/api/steganalysis', methods=['POST'])
def steganalysis():
    image_file = request.files.get('image')
    try:
        img_bytes = image_file.read()
        analyzer  = StegAnalyzer()
        result    = analyzer.analyze(img_bytes)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
